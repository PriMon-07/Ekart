package com.infosys.ekart.sellerOne.dto;

public class CartItemDTO {

	private String userId;
	private String displayName;
	private String category;
	private Integer price;
	private Float discount;
	private Integer quantity;
	private Float deliveryCharge;
	private Float total ;
	private Float cartOfferPrice;
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getDisplayName() {
		return displayName;
	}
	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public Integer getPrice() {
		return price;
	}
	public void setPrice(Integer price) {
		this.price = price;
	}
	public Float getDiscount() {
		return discount;
	}
	public void setDiscount(Float discount) {
		this.discount = discount;
	}
	public Integer getQuantity() {
		return quantity;
	}
	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}
	public Float getDeliveryCharge() {
		return deliveryCharge;
	}
	public void setDeliveryCharge(Float deliveryCharge) {
		this.deliveryCharge = deliveryCharge;
	}
	public Float getTotal() {
		return total;
	}
	public void setTotal(Float total) {
		this.total = total;
	}
	public Float getCartOfferPrice() {
		return cartOfferPrice;
	}
	public void setCartOfferPrice(Float cartOfferPrice) {
		this.cartOfferPrice = cartOfferPrice;
	}
	public CartItemDTO(String userId, String displayName, String category, Integer price, Float discount, Integer quantity,
			Float deliveryCharge, Float total, Float cartOfferPrice) {
		super();
		this.userId = userId;
		this.displayName = displayName;
		this.category = category;
		this.price = price;
		this.discount = discount;
		this.quantity = quantity;
		this.deliveryCharge = deliveryCharge;
		this.total = total;
		this.cartOfferPrice = cartOfferPrice;
	}
	public CartItemDTO() {
		super();
	}
	
	
}

