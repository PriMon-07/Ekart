package com.infosys.ekart.sellerOne.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.infosys.ekart.sellerOne.dto.BaseResponse;
import com.infosys.ekart.sellerOne.dto.CartItemDTO;
import com.infosys.ekart.sellerOne.dto.CartOfferDTO;
import com.infosys.ekart.sellerOne.dto.NotificationModel;
import com.infosys.ekart.sellerOne.dto.ProductDTO;
import com.infosys.ekart.sellerOne.dto.ProductDetailsDTO;
import com.infosys.ekart.sellerOne.dto.SellerDTO;
import com.infosys.ekart.sellerOne.dto.StringResponse;
import com.infosys.ekart.sellerOne.exception.ProductNameAlreadyPresent;
import com.infosys.ekart.sellerOne.service.SellerService;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@RestController
@CrossOrigin
public class SellerController {

	@Autowired
	Environment environment;

	@Autowired
	RestTemplate restTemplate;
	
	Logger logger = LoggerFactory.getLogger(this.getClass());

	
	/*US36*/
	@RequestMapping(value = "/product/{productName}/modify", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<BaseResponse> modifyProductBySeller(@RequestBody SellerDTO sellerDTO,
			@PathVariable String productName) {
		String productURI="http://PRODUCTMS";
		return restTemplate.postForEntity(productURI+"/product/"+productName+"/modify/sellerOne", sellerDTO, BaseResponse.class);
	}
	
	@HystrixCommand(fallbackMethod = "addProductsFallback")
	@RequestMapping(value = "/product/add", method = RequestMethod.POST, headers = "Accept=application/json")
	public BaseResponse addProducts(@RequestBody ProductDTO productDTO,
			BindingResult result) throws ProductNameAlreadyPresent {
		logger.info("calling productMS to add products");
		String productURI="http://PRODUCTMS";
		return restTemplate.postForObject(productURI + "/product/add/sellerOne", productDTO,BaseResponse.class);
	}

	public BaseResponse addProductsFallback(@RequestBody ProductDTO productDTO,
			BindingResult result) throws ProductNameAlreadyPresent {
		return new BaseResponse();
	}
	// Ashish US-34,35
	@HystrixCommand(fallbackMethod = "getProductsFallback")
	@RequestMapping(value = "/products", method = RequestMethod.GET, headers = "Accept=application/json")
	public List<ProductDetailsDTO> getProducts() {
		System.out.println("inside seller product controller");
		logger.info("calling productMs to get list of products");
		String productURI="http://PRODUCTMS";
		return restTemplate.exchange(productURI + "/products/sellerOne", HttpMethod.GET, null,
				new ParameterizedTypeReference<List<ProductDetailsDTO>>() {
				}).getBody();
	}

	public List<ProductDetailsDTO> getProductsFallback() {
		return new ArrayList<>();
	}
    //Babita  US-37
		@RequestMapping(value = "/productsincart", method = RequestMethod.GET, headers = "Accept=application/json")
		public List<CartItemDTO> getProductsInCart() {
			String productURI="http://PRODUCTMS";
			System.err.println("inside seller");
			return restTemplate.exchange(productURI + "/productsincart/sellerOne", HttpMethod.GET, null,
					new ParameterizedTypeReference<List<CartItemDTO>>() {
					}).getBody();
		}
		
		@PostMapping(value = "/updatecart/{userId}/{productName}")
		public ResponseEntity<BaseResponse> modifyOfferCartPrice(@RequestBody CartOfferDTO cartOfferDTO,
				@PathVariable String userId, @PathVariable String productName) throws Exception {
			logger.info("Updating cart of user  : {}  ", userId);
			String cartUri = "http://CARTMS";
			System.err.println("iN PRODUCT");
			BaseResponse response = new BaseResponse();
			try {
				cartOfferDTO.setProductName(productName);
				cartOfferDTO.setSellerName("sellerOne");
//				cart
				NotificationModel notification = new NotificationModel();
				BaseResponse res=	restTemplate.postForObject(cartUri + "/"+userId+"/modifycart" , cartOfferDTO, BaseResponse.class);
				notification.setUserId(userId);
				notification.setMessage("Items in your cart has been offered a new price");
				notification.setMessageType("changes in cart");
				ResponseEntity<BaseResponse> response1 = restTemplate
						.postForEntity("http://NOTIFICATIONMS/notifications/add", notification, BaseResponse.class);
				//						BaseResponse.class).getBody();
//				BaseResponse res=	restTemplate.exchange(cartUri + "/cart/seller/updateprice" , HttpMethod.POST, null,
//						BaseResponse.class).getBody();
//				BaseResponse status = new RestTemplate().postForObject("http://CARTMS/cart/seller/updateprice",
////						cartOfferDTO, String.class);
//				logger.info("Offer price added");
//				response = new BaseResponse("success", HttpStatus.OK.value());
				return new ResponseEntity<>(res, HttpStatus.OK);
			} catch (Exception e) {
				e.printStackTrace();
				response = new BaseResponse("Failure", HttpStatus.BAD_REQUEST.value());
				return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
			}
		}
}
