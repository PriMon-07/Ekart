package com.infosys.ekart.sellerOne.service;

import com.infosys.ekart.sellerOne.dto.NotificationModel;
import com.infosys.ekart.sellerOne.dto.SellerDTO;

public interface SellerService {
	public NotificationModel modifyProduct(SellerDTO sellerDTO);
}
