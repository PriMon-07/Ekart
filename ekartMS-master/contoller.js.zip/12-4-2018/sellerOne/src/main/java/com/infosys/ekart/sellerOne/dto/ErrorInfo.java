package com.infosys.ekart.sellerOne.dto;

public class ErrorInfo {
	private String message;

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
}
