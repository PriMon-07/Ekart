package com.infosys.ekart.wishlist.exception;

public class UserNotRegisteredException extends AccountServiceException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public UserNotRegisteredException(String message) {
		super(message);
	}

}
