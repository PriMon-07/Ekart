package com.infosys.ekart.wishlist.exception;

@SuppressWarnings("serial")
public class ErrorOnServerException extends Exception {

	public ErrorOnServerException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
