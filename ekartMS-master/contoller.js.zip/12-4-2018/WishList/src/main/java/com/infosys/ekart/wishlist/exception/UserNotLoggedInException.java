package com.infosys.ekart.wishlist.exception;

public class UserNotLoggedInException extends AccountServiceException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public UserNotLoggedInException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
