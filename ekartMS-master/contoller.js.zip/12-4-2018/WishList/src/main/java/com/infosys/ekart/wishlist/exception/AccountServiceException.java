package com.infosys.ekart.wishlist.exception;

@SuppressWarnings("serial")
public class AccountServiceException extends Exception {

	public AccountServiceException(String message) {
		super(message);
	}

}
