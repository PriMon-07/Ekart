package com.infosys.ekart.wishlist.utility;

public class Response {

	private String response;

	public Response(String response) {
		this.response = response;
	}

	public String getBaseResponse() {
		return this.response;
	}

}
