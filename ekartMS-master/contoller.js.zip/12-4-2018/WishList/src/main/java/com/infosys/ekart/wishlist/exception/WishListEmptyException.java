package com.infosys.ekart.wishlist.exception;

public class WishListEmptyException extends AccountServiceException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public WishListEmptyException(String message) {
		super(message);
	}

}
