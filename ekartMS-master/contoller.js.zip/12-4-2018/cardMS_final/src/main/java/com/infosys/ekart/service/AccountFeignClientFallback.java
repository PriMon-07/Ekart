package com.infosys.ekart.service;

import org.springframework.stereotype.Component;

@Component
public class AccountFeignClientFallback implements AccountFeignClient{

	@Override
	public Boolean checkUser(String userId) {
		return false;
	}

}
