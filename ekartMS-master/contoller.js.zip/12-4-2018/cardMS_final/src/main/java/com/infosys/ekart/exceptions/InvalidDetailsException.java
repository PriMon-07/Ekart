package com.infosys.ekart.exceptions;

public class InvalidDetailsException extends Exception {
	private static final long serialVersionUID = -1802251971037762204L;

	public InvalidDetailsException(String message) {
		super(message);
	}

}
