package com.infosys.ekart.service;

import java.util.Set;
import java.util.TreeSet;

import org.springframework.stereotype.Component;

@Component
public class OrderFeignClientFallback implements OrderFeignClient{

	@Override
	public Set<String> getCategorySet(String userId) {
		return new TreeSet<>();
	}

}
