package com.infosys.ekart.exception;

@SuppressWarnings("serial")
public class CanNotBeEmptyException extends Exception{
	public CanNotBeEmptyException(String message) {
		super(message);
	}

}
