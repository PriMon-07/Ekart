package com.infosys.ekart.model;

public class UserCartDTO {
	private String userId;
	private String productName;
	private String category;
	private Float price;
	//private Float discount;
	private Integer quantity;
	private Float deliveryCharge;
	private Float total ;
	private Float cartOfferPrice;
	private Integer cartId;
	private String sellerName;
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public Float getPrice() {
		return price;
	}
	public void setPrice(Float price) {
		this.price = price;
	}
	public Integer getQuantity() {
		return quantity;
	}
	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}
	public Float getDeliveryCharge() {
		return deliveryCharge;
	}
	public void setDeliveryCharge(Float deliveryCharge) {
		this.deliveryCharge = deliveryCharge;
	}
	public Float getTotal() {
		return total;
	}
	public void setTotal(Float total) {
		this.total = total;
	}
	public Float getCartOfferPrice() {
		return cartOfferPrice;
	}
	public void setCartOfferPrice(Float cartOfferPrice) {
		this.cartOfferPrice = cartOfferPrice;
	}
	public Integer getCartId() {
		return cartId;
	}
	public void setCartId(Integer cartId) {
		this.cartId = cartId;
	}
	public String getSellerName() {
		return sellerName;
	}
	public void setSellerName(String sellerName) {
		this.sellerName = sellerName;
	}
	
	public UserCartDTO(String userId, String productName, String category, Float price, Integer quantity,
			Float deliveryCharge, Float total, Float cartOfferPrice, Integer cartId, String sellerName) {
		super();
		this.userId = userId;
		this.productName = productName;
		this.category = category;
		this.price = price;
		this.quantity = quantity;
		this.deliveryCharge = deliveryCharge;
		this.total = total;
		this.cartOfferPrice = cartOfferPrice;
		this.cartId = cartId;
		this.sellerName = sellerName;
	}
	public UserCartDTO() {
		super();
	}
	@Override
	public String toString() {
		return "UserCartDTO [userId=" + userId + ", productName=" + productName + ", category=" + category + ", price="
				+ price + ", quantity=" + quantity + ", deliveryCharge=" + deliveryCharge + ", total=" + total
				+ ", cartOfferPrice=" + cartOfferPrice + ", cartId=" + cartId + ", sellerName=" + sellerName + "]";
	}
}

