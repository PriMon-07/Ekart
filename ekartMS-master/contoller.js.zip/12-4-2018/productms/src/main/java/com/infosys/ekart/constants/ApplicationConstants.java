package com.infosys.ekart.constants;

public class ApplicationConstants {
	public static final String GET_DEALS = "/deals";
	public static final String GET_PRICE_COMPARISON = "/{productName}/pricecomparison";
	public static final String GET_RECOMMENDATIONS="/{userId}/recommendations";
	public static final String COMMA = ",";
	
	public static final String ORDER_MS = "OrderMS";
	public static final String GET_CATEGORIES = "/{userId}/getcategories";
	public static final String USER_ID = "userId";
	
	public static final String REVIEW_MS = "ReviewMS";
	public static final String GET_RATINGS = "/{productName}/getratings";
	public static final String PRODUCT_NAME = "productName";
	
	public static final String GET_SELLER_ORDER="{sellerName}/sellerorders";
	public static final String ADD_PRODUCT="/product/add/{sellerId}";
	public static final String GET_PRODUCT="/products/{sellerId}";
	
	public static final String GET_USER_CART ="/productsincart/{sellerId}";
	public static final String POST_UPDATE_CART="/updatecart/{userId}/{productName}";
	public static final String GET_DELIVER_ORDER="/{userId}/orders/{orderId}/deliver";
//	public static final String GET_SELLER_ORDER="/{sellerName}/sellerorders"; 
}
