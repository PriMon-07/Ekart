package com.infosys.ekart.exception;

@SuppressWarnings("serial")
public class ProductNameAlreadyPresent extends Exception{
	public ProductNameAlreadyPresent(String message) {
		super(message);
	}

}
