package com.infosys.ekart;

import org.junit.Test;

//@RunWith(SpringRunner.class)
//@SpringBootTest
public class NotificationMsApplicationTests {

	@Test
	public void contextLoads() {
	}

}
