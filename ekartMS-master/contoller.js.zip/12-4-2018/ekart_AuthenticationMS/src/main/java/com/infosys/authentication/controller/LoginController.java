package com.infosys.authentication.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.infosys.authentication.model.BaseResponse;
import com.infosys.authentication.model.LoginCredentials;
import com.infosys.authentication.service.LoginService;

@RestController
//@CrossOrigin
public class LoginController {

	@Autowired
	private LoginService loginService;
		
	@RequestMapping(value = ControllerPaths.LOGIN_CONTROLLER, method = RequestMethod.POST)
	public @ResponseBody ResponseEntity<BaseResponse> validateSim(@RequestBody LoginCredentials loginCredentials) {
		System.out.println("asfdsadsadasds");
		String response = "";
		response = loginService.verifyUser(loginCredentials);
		HttpStatus status = HttpStatus.OK;
		if (response.isEmpty() || response.contains("Error:")) {
			status = HttpStatus.NOT_FOUND;
		}
		System.err.println(response);
		BaseResponse responsee=new  BaseResponse();
		responsee.setMessage(response);
		return new ResponseEntity<BaseResponse>(responsee, status);
	}
}
