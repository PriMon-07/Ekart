package com.infosys.authentication.service;

import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.infosys.authentication.entity.UserEntity;
import com.infosys.authentication.exceptions.InvalidDetailsException;
import com.infosys.authentication.model.LoginCredentials;
import com.infosys.authentication.repository.UserRepository;

@Service
public class LoginService {

	@Autowired
	private UserRepository userRepository;

	@Value("${EKART.INVALID_DETAILS}")
	private String invalidDetails;
	
	@Value("${EKART.INVALID_USER}")
	private String invalidUser;

	public String verifyUser(LoginCredentials loginCredentials) {

		String response = "";
		try {
			UserEntity userEntity = userRepository.findByUserId(loginCredentials.getUserId());
			if (Objects.isNull(userEntity)) {
				throw new InvalidDetailsException(invalidUser);
			}
			if (!(userEntity.getPassword().equals(loginCredentials.getPassword()))) {
				throw new InvalidDetailsException(invalidDetails);
			}
			if("Seller".equals(userEntity.getAccountType()))
			{
				String[] seller=userEntity.getUserId().split("@");
				response = "Seller:"+seller[0];
			}
			else {
				
				response = "You have successfully logged in!!!";
			}
		} catch (Exception e) {
			e.printStackTrace();
			response = "Error:"+e.getMessage();
		}
		return response;
	}
}
