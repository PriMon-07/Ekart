package com.infosys.authentication.exceptions;

public class InvalidDetailsException extends Exception {

	private static final long serialVersionUID = 1L;

	public InvalidDetailsException(String message) {
		super(message);
	}

}
