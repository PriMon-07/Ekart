package com.infosys.authentication.controller;

public final class ControllerPaths {

	public static final String LOGIN_CONTROLLER = "/login";

}
