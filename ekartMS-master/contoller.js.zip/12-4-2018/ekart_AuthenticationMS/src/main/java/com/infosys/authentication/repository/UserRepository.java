package com.infosys.authentication.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.infosys.authentication.entity.UserEntity;

public interface UserRepository extends JpaRepository<UserEntity, String> {

	UserEntity findByUserId(String userId);

}
