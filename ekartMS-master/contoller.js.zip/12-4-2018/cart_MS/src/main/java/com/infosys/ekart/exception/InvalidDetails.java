package com.infosys.ekart.exception;

@SuppressWarnings("serial")
public class InvalidDetails extends Exception {
	public InvalidDetails(String message) {
		super(message);
	}
}
