/* added by dhanapriya */
package com.infosys.ekart.exception;

@SuppressWarnings("serial")
public class QuantityValueExceededException extends Exception {

	public QuantityValueExceededException(String message) {
		super(message);
	}
}
