/* added by dhanapriya */
package com.infosys.ekart.exception;

@SuppressWarnings("serial")
public class ModifyCartException extends Exception {
	public ModifyCartException(String message) {
		super(message);
	}

}
