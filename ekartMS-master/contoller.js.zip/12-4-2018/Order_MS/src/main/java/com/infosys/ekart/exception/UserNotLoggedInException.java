package com.infosys.ekart.exception;

@SuppressWarnings("serial")
public class UserNotLoggedInException extends Exception {

	public UserNotLoggedInException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
