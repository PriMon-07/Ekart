package com.infosys.ekart.service;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.infosys.ekart.entitiy.OrderEntity;
import com.infosys.ekart.exception.InvalidOrderId;
import com.infosys.ekart.exception.OrderNotDelivered;
import com.infosys.ekart.repository.OrderRepository;

@Service
public class OrderReturnService {
	@Autowired
	private OrderRepository orderRepository;
	@Autowired
	private Environment environment;

	@SuppressWarnings("unused")
	public void startReturn(String userId, long orderId) throws InvalidOrderId, OrderNotDelivered {
		
		OrderEntity order = orderRepository.findByUserIdAndOrderId(userId, orderId);
		
		
		LocalDate start = LocalDate.parse(order.getOrderedDate().toString());
		LocalDate end = LocalDate.parse(order.getDeliveryDate().toString());
		Long daysPassed = ChronoUnit.DAYS.between(start, end);
		
		if (order == null) {
			throw new InvalidOrderId(environment.getProperty("WRONG_ORDER_ID"));
		} else if (!order.getOrderStatus().equalsIgnoreCase("delivered")) {
			throw new OrderNotDelivered(environment.getProperty("NOT_DELIVERED"));
		} else if (daysPassed > 7) {
			throw new OrderNotDelivered(environment.getProperty("RETURN_DATE_PASSED"));
		}
		order.setOrderStatus("returned");
		orderRepository.saveAndFlush(order);
		
	}
}
